call import "android.r"
call AndroidInit
call cameraCapturePicture "/mnt/sdcard/foo.jpg"
